<?php $__env->startSection('master-admin'); ?>

<h3>Lorem ipsum dolor sit amet consectetur adipisicing elit. A facere molestiae magni laborum, corrupti laboriosam facilis similique voluptatum itaque, adipisci architecto, eum non hic harum? Quaerat aut sunt quibusdam minus!</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\akiny\Pictures\raffleitapp\raffleitapp\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>