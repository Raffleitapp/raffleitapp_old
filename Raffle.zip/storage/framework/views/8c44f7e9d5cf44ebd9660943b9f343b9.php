<?php $__env->startSection('master-admin'); ?>
<meta name="_token" content="<?php echo e(csrf_token()); ?>">

    <style>
        .card {
            border-radius: 10px;
            border: 1px solid #215273;
            box-shadow: 0px 0px 5px 0px rgba(0, 0, 0, 0.25);
        }

        label {
            color: #303030;
            /* H5 Bold */
            font-family: Poppins;
            font-size: 14px;
            font-style: normal;
            font-weight: 700;
            line-height: 140%;
        }

        h2 {
            color: #161616;
            text-align: center;
            font-family: Prompt;
            font-size: 24px;
            font-style: normal;
            font-weight: 900;
            line-height: 96.5%;
        }

        button[type="submit"] {
            border-radius: 10px;
            background: var(--Button-Color, #55C595);
            color: #ffffff;
            text-align: center;
            font-family: Prompt;
            font-size: 14px;
            font-style: normal;
            font-weight: 900;
            line-height: 96.5%;
        }
    </style>
    <div class="container overflow-hidden p-3" style="min-height: 65vh; vertical-align:center">
        <div class="card p-3 mx-auto" style=" max-width:600px; border-radius:12px;">
            

            <h2>View Admin</h2>

            <?php if(session()->has('message')): ?>
            <div class="alert text-center alert-danger" role="alert">
                <?php echo e(session()->get('message')); ?>

            </div>
            <?php endif; ?>
            
            <form class="p-3" action="<?php echo e(url('admin/addAdmin')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label>First Name</label>
                    <input type="text" placeholder="Enter first name" name="first_name" readonly value="<?php echo e($data->first_name); ?>" autocomplete="off" class="required:border-red-500 form-control" required>
                </div>
                <div class="form-group mb-3">
                    <label>Last Name</label>
                    <input type="text" placeholder="Enter last name" autocomplete="off" name="last_name" readonly value="<?php echo e($data->last_name); ?>"  class="required:border-red-500 form-control"
                        required>
                </div>
                <div class="form-group mb-3">
                    <label>Email Address</label>
                    <input type="email" placeholder="Enter email address" autocomplete="off" name="email" readonly value="<?php echo e($data->email); ?>"  class="required:border-red-500 form-control"
                        required>
                </div>
                <div class="form-group mb-3">
                    <label>Username</label>
                    <input type="text" placeholder="Enter username" autocomplete="off" name="username" readonly value="<?php echo e($data->username); ?>"  class="required:border-red-500 form-control"
                        required>
                </div>
                
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\akiny\Documents\Raffle\resources\views/admin/edit-admin.blade.php ENDPATH**/ ?>