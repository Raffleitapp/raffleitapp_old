<?php $__env->startSection('title', 'Addresses'); ?>
<?php $__env->startSection('content'); ?>

<style>
    label {
        font-weight: bold;
    }
</style>

<div class="address p-4">
    <h6>The following addresses will be used on the checkout page by default.</h6>
    <div class="row">
        <div class="col-md-6">
            <h5 class="fw-bold mt-4">Billing Addresses</h5>
            <h6>You have not set up this type of address yet.</h6>
            <button onclick="location.href='<?php echo e(url('billaddress')); ?>'" class="btn fw-bold">Add</button>
        </div>
        <div class="col-md-6">
            <h5 class="fw-bold mt-4">Shipping Addresses</h5>
            <h6>You have not set up this type of address yet.</h6>
            <button onclick="location.href='<?php echo e(url('shipaddress')); ?>'" class="btn fw-bold">Add</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\akiny\Pictures\raffleitapp\raffleitapp\resources\views/addresses.blade.php ENDPATH**/ ?>