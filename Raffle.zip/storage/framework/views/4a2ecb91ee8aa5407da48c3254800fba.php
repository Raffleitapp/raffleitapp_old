<?php $__env->startSection('master-admin'); ?>
<style>
    h2.head {
        color: #000;

        /* H3 Bold */
        font-family: Poppins;
        font-size: 1.5rem;
        font-style: normal;
        font-weight: 700;
        line-height: 90%;
    }

    p.head-desc {
        color: #000;

        /* Title 1 */
        font-family: Poppins;
        font-size: .8rem;
        font-style: normal;
        font-weight: 400;
        line-height: 90%;
    }

    table thead {
        background: var(--primary-color);
        color: var(--white-color);
        padding: 8px 0px;

    }

    table thead tr {
        padding: 8px 0px;
        color: var(--white-color, #FDFDFD);
        /* Title 3 Bold */
        font-family: Poppins;
        font-size: 14px;
        font-style: normal;
        font-weight: 700;
        line-height: 140%;
    }

    .profile-image{
        height: 50px;
        width: 50px;
        border-radius: 50%;
        object-fit: cover;
        object-position: center;
    }
</style>
<div class="p-3">
    <h2 class="head">Payment Settings</h2>
    <p class="head-desc">Manage payment settings</p>

</div>
<?php
    $data = DB::table('payment_settings')->where('id', 1)->first();
?>
<div class="card p-3 mx-auto" style="max-width: 600px">
    <form class="p-3" method="POST" action="<?php echo e(route('admin.update-payment')); ?>">
        <div class="form-group mb-3">
            <label for="">Secret</label>
            <input type="text" required name="p_secret" value="<?php echo e($data->code_access); ?>" class="form-control">
        </div>
        <div class="form-group mb-3">
            <label for="">Key</label>
            <input type="text" required name="p_key" value="<?php echo e($data->payment_name); ?>" class="form-control">
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-success btn-sm">Update</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\akiny\Documents\Raffle\resources\views/admin/payment.blade.php ENDPATH**/ ?>