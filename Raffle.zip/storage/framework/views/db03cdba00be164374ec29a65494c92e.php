<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/me.css')); ?>">
    <?php if(!session()->has('user_id')): ?>
        <?php
            return redirect('/login');
        ?>
    <?php elseif(session()->get('user_type') == 'admin'): ?>
        <?php
            return redirect('admin/dashboard');
        ?>
    <?php endif; ?>
    <style>
        .custom-grid {
            display: grid;
            // padding: 12px;
            /* width: 90vw; */
            /* border:2px solid red; */
            grid-template-columns: repeat(auto-fit, minmax(250px, auto));
            justify-content: center;
            margin: 0px auto;
            gap: 10px;
        }

        .admin-sidebar {
            width: 100%;
            padding: 12px 0px;
        }

        .admin-sidebar .sidebar-item {
            background: #215273;
            padding: 10px 20px;
            list-style: none;
            margin: 0;
            border: #215273 1px solid;
            border-bottom: 1px solid white;
        }

        .sidebar-item:first-child {
            border-radius: 10px 10px 0 0;
        }

        .sidebar-item:last-child {
            border-radius: 0px 0px 10px 10px;
        }

        .sidebar-item a {
            color: white;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none
        }

        .sidebar-item:hover,
        .sidebar-item.active {
            background: #ffffff;
            /* opacity: 0.5; */
            cursor: pointer;
        }

        .sidebar-item:hover>a,
        .sidebar-item.active>a {
            color: #215273;
        }



        .sidebar-item.active {
            background: white;
        }

        .sidebar-item.active>a {
            color: #215273;
        }

        .container-user {
            /* background: yellow */
        }
    </style>


    <div class="container-user justify-center">
        <div class="custom-grid p-3 py-4">
            <div class="col-12">
                <div class="admin-sidebar animate__animated animate__fadeInLeft">

                    <li class="sidebar-item"><a href="#">My Tickets</a></li>

                    <li onclick="location.href='<?php echo e(url('user/dashboard')); ?>'"
                        class="sidebar-item <?php echo e(request()->is('user/dashboard*') ? 'active' : ''); ?>"><a
                            href="javascript:void(0)">Dashboard</a></li>
                    
                    <li onclick="location.href='<?php echo e(url('user/addresses')); ?>'"
                        class="sidebar-item <?php echo e(request()->is('user/addresses*') ? 'active' : ''); ?>"><a
                            href="javascript:void(0)">Addresses</a></li>
                    <li class="sidebar-item <?php echo e(request()->is('user/accdetails*') ? 'active' : ''); ?>"><a
                            href="<?php echo e(url('user/accdetails')); ?>">Account Details</a></li>
                    
                    <li class="sidebar-item" onclick="location.href='<?php echo e(url('logout')); ?>'"><a
                            href="javascript:void(0)">Logout</a href="javascript:void"></li>

                </div>
            </div>
            <div class="col-12">
                <?php echo $__env->yieldContent('contentss'); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
    $('#togglePassword').click(function() {
      const passwordInput = $('#password');
      // const passwordIcon = $('#passwordIcon');

      // Toggle the input type between 'password' and 'text'
      if (passwordInput.attr('type') === 'password') {
        passwordInput.attr('type', 'text');
        $(this).removeClass('bi bi-eye-fill').addClass('bi bi-eye-slash-fill');
      } else {
        passwordInput.attr('type', 'password');
        $(this).removeClass('bi bi-eye-slash-fill').addClass('bi bi-eye-fill');
      }
    });
    $('#ntogglePassword').click(function() {
      const passwordInput = $('#npassword');
      // const passwordIcon = $('#passwordIcon');

      // Toggle the input type between 'password' and 'text'
      if (passwordInput.attr('type') === 'password') {
        passwordInput.attr('type', 'text');
        $(this).removeClass('bi bi-eye-fill').addClass('bi bi-eye-slash-fill');
      } else {
        passwordInput.attr('type', 'password');
        $(this).removeClass('bi bi-eye-slash-fill').addClass('bi bi-eye-fill');
      }
    });
    $('#ctogglePassword').click(function() {
      const passwordInput = $('#cpassword');
      // const passwordIcon = $('#passwordIcon');

      // Toggle the input type between 'password' and 'text'
      if (passwordInput.attr('type') === 'password') {
        passwordInput.attr('type', 'text');
        $(this).removeClass('bi bi-eye-fill').addClass('bi bi-eye-slash-fill');
      } else {
        passwordInput.attr('type', 'password');
        $(this).removeClass('bi bi-eye-slash-fill').addClass('bi bi-eye-fill');
      }
    });
  });
</script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/arowojoludaniel/Documents/raffleitapp/resources/views/layouts/dashlayout.blade.php ENDPATH**/ ?>