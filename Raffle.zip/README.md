# raffleitapp
This app is to do raffles that in the end help the society and the people who participate while being able to profit its owners
